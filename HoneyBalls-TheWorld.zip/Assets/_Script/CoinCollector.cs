using UnityEngine;
using UnityEngine.UI;

public class CoinCollector : MonoBehaviour
{
    public int score = 0;
    public Text scoreText; // Arrastar el Text desde el Inspector
    
    void OnTriggerEnter(Collider other){
        if (other.CompareTag("Coin")){
            score++;
            Destroy(other.gameObject);
            scoreText.text = "Puntos: " + score;
        }
    }
}
