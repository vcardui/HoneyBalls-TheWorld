using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    public GameObject coinPrefab;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        for (int i = 0; i < 10; i++){
            Vector3 randomPos = new Vector3(Random.Range(-5, 5), 0.5f, Random.Range(-5, 5));
            Instantiate(coinPrefab, randomPos, Quaternion.identity);
        }
    }
}
