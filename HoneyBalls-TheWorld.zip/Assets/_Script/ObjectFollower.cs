using UnityEngine;

public class ObjectFollower : MonoBehaviour
{
    public Transform target; // Objeto a seguir
    public float speed = 5f;

    void Update(){
        // Mueve el objeto hacie el target
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        // Opcional: Rotar hacia el target
        Vector3 direction = (target.position - transform.position).normalized;
        if(direction != Vector3.zero){
            Quaternion lookRotation = Quaternion.LookRotation(direction);
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * speed);
        }
    }
}
