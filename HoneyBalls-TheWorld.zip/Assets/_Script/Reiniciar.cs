using UnityEngine;

public class Reiniciar : MonoBehaviour
{
   void OnCollisionEnter(Collision collision) {
    if (collision.gameObject.CompareTag("Player")){
        collision.gameObject.transform.position = new Vector3 (0, 1, 0); // Volver al inicio
    }
   }
}
